package com.example.hamburgueriaz;

import androidx.appcompat.app.AppCompatActivity;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private int quantidade = 0;
    private final double precoBase = 20.0; // Preço base do hamburguer
    private final double precoBacon = 2.0;
    private final double precoQueijo = 2.0;
    private final double precoOnionRings = 3.0;

    private TextView quantidadeView;
    private TextView precoTotalView;
    private TextView resumoPedidoView;
    private EditText nomeClienteEditText;
    private CheckBox baconCheckbox;
    private CheckBox queijoCheckbox;
    private CheckBox onionRingsCheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Inicializa as views
        Button btnAumentar = findViewById(R.id.btnAumentar);
        Button btnDiminuir = findViewById(R.id.btnDiminuir);
        quantidadeView = findViewById(R.id.quantidadeView);
        precoTotalView = findViewById(R.id.precoTotalView);
        resumoPedidoView = findViewById(R.id.resumoPedidoView);
        nomeClienteEditText = findViewById(R.id.nomeCliente);
        baconCheckbox = findViewById(R.id.baconCheckbox);
        queijoCheckbox = findViewById(R.id.queijoCheckbox);
        onionRingsCheckbox = findViewById(R.id.onionRingsCheckbox);
        Button btnFazerPedido = findViewById(R.id.btnFazerPedido);

        // Configura os listeners
        btnAumentar.setOnClickListener(v -> somar());
        btnDiminuir.setOnClickListener(v -> subtrair());

        View.OnClickListener checkboxListener = v -> atualizarPrecoTotal();
        baconCheckbox.setOnClickListener(checkboxListener);
        queijoCheckbox.setOnClickListener(checkboxListener);
        onionRingsCheckbox.setOnClickListener(checkboxListener);

        btnFazerPedido.setOnClickListener(v -> enviarPedido());
    }

    private void somar() {
        quantidade++;
        atualizarQuantidade();
        atualizarPrecoTotal();
    }

    private void subtrair() {
        if (quantidade > 0) {
            quantidade--;
            atualizarQuantidade();
            atualizarPrecoTotal();
        }
    }

    private void atualizarQuantidade() {
        quantidadeView.setText(String.valueOf(quantidade));
    }

    private void atualizarPrecoTotal() {
        double precoTotal = calcularPrecoTotal();
        precoTotalView.setText(String.format("R$ %.2f", precoTotal));
    }

    private double calcularPrecoTotal() {
        double precoAdicionais = 0;

        if (baconCheckbox.isChecked()) precoAdicionais += precoBacon;
        if (queijoCheckbox.isChecked()) precoAdicionais += precoQueijo;
        if (onionRingsCheckbox.isChecked()) precoAdicionais += precoOnionRings;

        return quantidade * (precoBase + precoAdicionais);
    }

    private void enviarPedido() {
        String nomeCliente = nomeClienteEditText.getText().toString().trim();

        if (nomeCliente.isEmpty()) {
            nomeCliente = "Cliente não identificado";
        }

        if (quantidade == 0) {
            resumoPedidoView.setText("Selecione pelo menos 1 hambúrguer");
            return;
        }

        double precoTotal = calcularPrecoTotal();

        String resumo = String.format(
                "Nome do cliente: %s\n\n" +
                        "Adicionais:\n" +
                        "• Bacon: %s\n" +
                        "• Queijo: %s\n" +
                        "• Onion Rings: %s\n\n" +
                        "Quantidade: %d\n" +
                        "Preço final: R$ %.2f",
                nomeCliente,
                baconCheckbox.isChecked() ? "Sim (+R$2,00)" : "Não",
                queijoCheckbox.isChecked() ? "Sim (+R$2,00)" : "Não",
                onionRingsCheckbox.isChecked() ? "Sim (+R$3,00)" : "Não",
                quantidade,
                precoTotal
        );

        resumoPedidoView.setText(resumo);
        enviarEmailPedido(nomeCliente, resumo);
    }

    private void enviarEmailPedido(String nomeCliente, String detalhesPedido) {
        Intent emailIntent = new Intent(Intent.ACTION_SENDTO);
        emailIntent.setData(Uri.parse("mailto:")); // Apenas apps de e-mail
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Pedido de " + nomeCliente);
        emailIntent.putExtra(Intent.EXTRA_TEXT, detalhesPedido);

        try {
            startActivity(Intent.createChooser(emailIntent, "Enviar pedido por e-mail"));
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Nenhum app de e-mail instalado", Toast.LENGTH_SHORT).show();
        }
    }
}